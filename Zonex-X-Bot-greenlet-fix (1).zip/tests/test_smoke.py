import ast
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / "main.py"
ENV_EXAMPLE = ROOT / ".env.example"


class ProjectSmokeTests(unittest.TestCase):
    def test_main_is_valid_python(self):
        source = MAIN.read_text(encoding="utf-8")
        ast.parse(source, filename=str(MAIN))

    def test_entrypoint_and_required_config_are_present(self):
        source = MAIN.read_text(encoding="utf-8")
        env = ENV_EXAMPLE.read_text(encoding="utf-8")

        self.assertIn('if __name__ == "__main__":', source)
        self.assertIn("asyncio.run(main())", source)
        self.assertIn("send_payment_proof_to_admins", source)
        self.assertIn("await bot.send_photo(", source)
        self.assertIn("await bot.send_document(", source)
        self.assertIn("BOT_TOKEN", env)
        self.assertIn("ADMIN_IDS", env)
        self.assertIn("DATABASE_URL", env)

    def test_database_and_bot_dependencies_are_declared(self):
        requirements = (ROOT / "requirements.txt").read_text(encoding="utf-8")
        for package in (
            "aiogram",
            "aiosqlite",
            "SQLAlchemy",
            "greenlet",
            "python-dotenv",
            "qrcode",
        ):
            self.assertIn(package, requirements)

    def test_railway_has_an_explicit_start_command(self):
        railway = (ROOT / "railway.json").read_text(encoding="utf-8")
        procfile = (ROOT / "Procfile").read_text(encoding="utf-8")
        self.assertIn('"startCommand": "python -u main.py"', railway)
        self.assertIn("python -u main.py", procfile)


if __name__ == "__main__":
    unittest.main()